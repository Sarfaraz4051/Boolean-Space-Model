package ir_ass;

import java.io.*;
import java.util.*;

public class IR_Ass {
     
    public static void main(String[] args) throws Exception{
        
        HashMap<String,ArrayList<Integer> > map = new HashMap<String, ArrayList<Integer> >();
        File dir=new File("C:\\Users\\3tee system\\Desktop\\6th semester\\IR\\stories");
        File[] listOfFiles = dir.listFiles();
        String word;
        int word_count=0,f=0,i=1,len,t;
        List<String> stopwords =Arrays.asList( "a" , "is" , "the" ,"of","all","and","to","can" ,"be","as","once","for","at",
                                                "am","are","has","have","had","up","his","her","in","on","no","we","do");
        for (File file : listOfFiles) {
            FileReader reader = new FileReader(file); 
            BufferedReader bufferread = new BufferedReader(reader); 
            StreamTokenizer token = new StreamTokenizer(bufferread);
            f++;
            String[] te=file.getName().split("[.]");//Converting name of file from String to Integer..
            String doc=te[0];
            int doc_id=Integer.parseInt(doc);//typecasting of string to int..
           token.whitespaceChars(' ' , '.');
          
            while ((t = token.nextToken()) != StreamTokenizer.TT_EOF) 
            {
                if (token.sval!=null)
                {         
            word=token.sval;
            word=word.toLowerCase();
            if(word.length()<5)//comparing only those words with Stopwords whose length is less than 5//
            {
                if(stopwords.contains(word))
                continue;
            }
            String[] tokens=word.split("[[,] ['] [:] [;] [!] [?] [-] [.] [\"] ]");
            for(String str:tokens){
                if(str.length()>1){ 
                    if(map.get(str)==null){
                        ArrayList<Integer> arrli = new ArrayList<Integer>();
                        arrli.add(doc_id);
                        map.put(str,arrli);
                    }
                    else{
                        ArrayList<Integer> arrli;
                        arrli=map.get(str);
                        if(!arrli.contains(doc_id))
                        arrli.add(doc_id);
                        map.put(str, arrli);
                        Collections.sort(arrli);
                    }
                }   
            }
        }
            }
        }
        System.out.println("Total Files Read: "+f);
        System.out.println("\n\nQUERY FORMAT---> CROWED OR NOT BYSY ");
        System.out.println("QUERY FORMAT---> BREAKFAST AND NOT BYSY");
        System.out.println("QUERY FORMAT---> NOT KING AND NOT QUEEN AND NOT LOVE ");

        System.out.println("\nWRONG QUERY FORMAT---> CROWED NOT BUSY ---->X");
        System.out.println("WRONG QUERY FORMAT---> BREAKFAST NOT BUSY ---->X");
        System.out.println("WRONG FORMAT---> NOT KING NOT QUEEN NOT LOVE ---->X \n");
        Scanner s=new Scanner(System.in);
        System.out.println("\n\n\t------------------------------------");
        System.out.print("\tENTER THE QUERY-->  ");
        String query=s.nextLine();
        System.out.print("\t-----------------------");
        for(int j=0;j<=query.length();j++)
        System.out.print("-");
        Evaluatequery(query,map);
}
//  //Function to Evaluate Query....
    public static ArrayList<Integer> Evaluatequery(String query,Map<String, ArrayList<Integer> > map){
        System.out.println("\n\nENTERED QUERY IS ----> "+query);
        System.out.println("<------------------------------------------------------------------->");
        query=query.toLowerCase();
        StringTokenizer st1 =new StringTokenizer(query);   //tokenization of user entered query
        ArrayList<String> temp=new ArrayList<String>();
        while (st1.hasMoreTokens()){ //saving tokens into array list 
        temp.add(st1.nextToken());
        }
        int i=0;
        ArrayList<Integer> result=new ArrayList<Integer>();
        for(i=0;i<temp.size();i++){
            String t=temp.get(i);
            if(t.equalsIgnoreCase("AND"))
            {
                if(!temp.get(i+1).equalsIgnoreCase("NOT")){
                result=AND(result,map.get(temp.get(i+1)));
                }
                else {
                    result=AND(result,NOT(map.get(temp.get(i+2))));
                    i++;
                }
                    i++;    
            }
            else if(t.equalsIgnoreCase("OR")){
                if(!temp.get(i+1).equalsIgnoreCase("NOT")){
                result=OR(result,map.get(temp.get(i+1)));
                }
                else {
                    result=OR(result,NOT(map.get(temp.get(i+2))));
                    i++;
                }
                i++;
            }
            else if(t.equalsIgnoreCase("NOT"))
            {
                result=NOT(map.get(temp.get(i+1))); 
                i++;
            }
            else if (result!=null){
            result=map.get(t);
            }
        }
        if(result!=null)
        System.out.println("Number Of Documents Retrieved: "+result.size());
        System.out.println("Retrived Documents are: "+result);
        return result;
    }
      //Function to PERFROM OR OPERATION
    public static ArrayList<Integer> OR(ArrayList<Integer> p1,ArrayList<Integer> p2)
    {
        if(p1==null) return p2;  
        else if (p2==null) return p1;
        else
        {
            ArrayList<Integer> result =new  ArrayList<Integer> ();
            int i=0,j=0,k=0,x,y;
            while(i!=p1.size() && j!=p2.size())
                    {
			x = p1.get(i);
                        y = p2.get(j);
			if(x==y)
                        {
				result.add(x);
				i++;
				j++;
			}
			else if(x < y)
                        {	
                            result.add(x);
                            i++;
                        }
                        else
                        {	result.add(y);
				j++;
		
                        }
                }            
         return result;
        }
       
    }
    
      //Function to PERFROM NOT OPERATION
    public static ArrayList<Integer> NOT(ArrayList<Integer> al)
    {
        ArrayList<Integer> result =new  ArrayList<Integer> ();
        int i,size=0;
        if(al == null)
        {
            size=0;
        }
        else{
        size=al.size();
        }
        for(i=1;i<=50;i++)    {
                result.add(i);
        }
        i=0;
        while(size!=0)        {
            result.remove(al.get(i));
            size--;
            i++;
        }
        return result;
    }
    
    
  public static void print(Map<String, ArrayList<Integer> > map)  
    { 
        if (!map.isEmpty())  
        { 
                        System.out.println(map); 
        } 
        else
        { 
            System.out.println("map is empty"); 
        } 
    } 
  //Function to PERFROM AND OPERATION
  public static ArrayList<Integer> AND(ArrayList<Integer> P1,ArrayList<Integer> P2){
		ArrayList <Integer> result = new ArrayList <> ();
                int i=0,j=0,x,y;
                if(P1==null || P2==null)
                {
                    return null;
                }else{
                    while(i!=P1.size() && j!=P2.size())
                    {
			x = P1.get(i);
                        y = P2.get(j);
			if(x==y)
                        {
				result.add(x);
				i++;
				j++;
			}
			else if(x < y)
                        {	
                            i++;
                        }
                        else
                        {	j++;
		
                        }
                }}
		return result;
	}
}